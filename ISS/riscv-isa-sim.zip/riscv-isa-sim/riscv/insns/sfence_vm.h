require_privilege(PRV_S);
MMU.flush_tlb();
