if(RS1 < RS2)
  set_pc(BRANCH_TARGET);
