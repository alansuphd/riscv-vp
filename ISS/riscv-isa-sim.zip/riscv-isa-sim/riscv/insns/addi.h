WRITE_RD(sext_xlen(RS1 + insn.i_imm()));
