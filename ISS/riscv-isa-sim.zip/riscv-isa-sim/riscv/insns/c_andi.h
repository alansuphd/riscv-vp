require_extension('C');
WRITE_RVC_RS1S(RVC_RS1S & insn.rvc_imm());
