require_extension('D');
require_fp;
WRITE_RD(f64_le(f64(FRS1), f64(FRS2)));
set_fp_exceptions;
