require_rvc;
require_fp;
FCRDS = mmu.load_int64(CRS1S+CIMM5*8);
