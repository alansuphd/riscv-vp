require_rvc;
CRDS = mmu.load_int32(CRS1S+CIMM5*4);
