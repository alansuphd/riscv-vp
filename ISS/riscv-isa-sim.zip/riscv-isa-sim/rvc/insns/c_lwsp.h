require_rvc;
CRD = mmu.load_int32(XPR[30]+CIMM6*4);
