require_rvc;
require_fp;
mmu.store_uint64(CRS1S+CIMM5*8, FCRS2S);
